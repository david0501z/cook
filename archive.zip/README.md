# 菜谱大全APP

一个简单而功能完整的安卓菜谱管理应用，支持随机菜品推荐和菜谱维护功能。

## 功能特性

### 🍳 随机菜品推荐
- 智能随机推荐菜品
- 显示制作过程图文
- 菜品详细信息展示
- 一键换个推荐

### 📚 菜谱管理
- 添加、编辑、删除菜谱
- 按分类筛选菜谱
- 搜索菜谱功能
- 菜谱收藏和分享

## 技术架构

- **框架**: Flutter 3.x
- **语言**: Dart
- **数据库**: SQLite (sqflite)
- **状态管理**: Provider
- **UI设计**: Material Design 3

## 项目结构

```
lib/
├── main.dart                    # 应用入口
├── models/
│   └── recipe.dart             # 菜谱数据模型
├── providers/
│   └── recipe_provider.dart    # 状态管理
├── database/
│   └── database_helper.dart    # 数据库操作
└── screens/
    ├── home_screen.dart        # 主界面
    ├── random_recipe_tab.dart  # 随机推荐页面
    ├── recipe_management_tab.dart # 菜谱管理页面
    ├── recipe_detail_screen.dart  # 菜谱详情页面
    └── add_edit_recipe_screen.dart # 添加/编辑菜谱页面
```

## 预置菜谱

应用内置了10道经典中式菜谱，包括：

### 川菜类
- 宫保鸡丁
- 麻婆豆腐
- 鱼香肉丝

### 粤菜类
- 白切鸡
- 蒸蛋羹

### 家常菜类
- 番茄炒蛋
- 红烧排骨
- 青椒肉丝
- 酸辣土豆丝
- 清蒸鲈鱼

## 安装和使用

### 环境要求
- Flutter SDK 3.0+
- Dart SDK 3.0+
- Android Studio / VS Code

### 运行步骤

1. 克隆项目
```bash
git clone <repository-url>
cd recipe_app
```

2. 安装依赖
```bash
flutter pub get
```

3. 运行应用
```bash
flutter run
```

## 开发说明

### 数据库设计
- 表名: `recipes`
- 主要字段: id, name, category, description, ingredients, steps, imagePath, cookingTime, difficulty, createdAt

### 核心功能
- 随机菜谱推荐算法
- SQLite本地数据库存储
- Provider状态管理
- Material Design 3 UI组件

## 未来计划

- [ ] 图片上传功能
- [ ] 菜谱评分系统
- [ ] 购物清单生成
- [ ] 营养成分分析
- [ ] 云端同步功能

## 许可证

MIT License